export default {content:['./index.html','./src/**/*.{js,jsx}'],theme:{extend:{fontFamily:{sans:['"DM Sans"','system-ui','sans-serif'],display:['Sora','sans-serif']}}},plugins:[]}
