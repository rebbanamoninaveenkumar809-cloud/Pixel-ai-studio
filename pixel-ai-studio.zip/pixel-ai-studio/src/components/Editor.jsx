import {useEffect,useRef,useState} from 'react'
import {saveProject,logDownload} from '../lib/store'
export const SIZES={thumbnail:[1280,720],shorts:[1080,1920],poster:[1200,1600],banner:[2560,1440],logo:[1024,1024],image:[1080,1080]}
const BGS=['#7c3aed,#2563eb','#1e0a3c,#6d28d9','#06b6d4,#7c3aed','#020617,#2563eb','#6d28d9,#db2777']
const FONTS=['Sora','Impact','Georgia','Courier New']
const FILTERS={None:'none',Vivid:'saturate(1.6) contrast(1.1)',Mono:'grayscale(1)',Soft:'blur(2px) brightness(1.1)'}
const AI=import.meta.env.VITE_AI_ENDPOINT

export default function Editor({preset='thumbnail',user}){
  const [W,H]=SIZES[preset]||SIZES.thumbnail
  const cv=useRef(),cache=useRef({}),drag=useRef(null)
  const [st,setSt]=useState(()=>{try{const o=sessionStorage.getItem('pas_open');if(o)return JSON.parse(o)}catch{}
    return{bg:BGS[0],filter:'None',layers:[{id:1,t:'text',x:W/2,y:H/2,text:'YOUR TITLE',size:Math.round(W/8),color:'#ffffff',font:'Impact'}]}})
  const [past,setPast]=useState([]),[future,setFuture]=useState([])
  const [sel,setSel]=useState(st.layers[0]?.id),[msg,setMsg]=useState(''),[busy,setBusy]=useState(false),[prompt,setPrompt]=useState('')
  useEffect(()=>{sessionStorage.removeItem('pas_open')},[])
  const commit=n=>{setPast(p=>[...p,st]);setFuture([]);setSt(n)}
  const undo=()=>{if(!past.length)return;setFuture(f=>[st,...f]);setSt(past.at(-1));setPast(p=>p.slice(0,-1))}
  const redo=()=>{if(!future.length)return;setPast(p=>[...p,st]);setSt(future[0]);setFuture(f=>f.slice(1))}
  const upd=patch=>commit({...st,layers:st.layers.map(l=>l.id===sel?{...l,...patch}:l)})
  const cur=st.layers.find(l=>l.id===sel)

  useEffect(()=>{
    const ctx=cv.current.getContext('2d'),[a,b]=st.bg.split(',')
    const g=ctx.createLinearGradient(0,0,W,H);g.addColorStop(0,a);g.addColorStop(1,b)
    ctx.fillStyle=g;ctx.fillRect(0,0,W,H)
    for(const l of st.layers){
      if(l.t==='img'){
        const im=cache.current[l.id]
        if(!im){const i=new Image();i.onload=()=>{cache.current[l.id]=i;setSt(s=>({...s}))};i.src=l.src;continue}
        ctx.filter=FILTERS[st.filter]||'none';ctx.drawImage(im,l.x-l.w/2,l.y-l.h/2,l.w,l.h);ctx.filter='none'
      }else{
        ctx.font=`${l.size}px ${l.font}`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.lineJoin='round'
        ctx.lineWidth=l.size/8;ctx.strokeStyle='#000';ctx.strokeText(l.text,l.x,l.y);ctx.fillStyle=l.color;ctx.fillText(l.text,l.x,l.y)
      }
    }
  },[st,W,H])

  const pos=e=>{const r=cv.current.getBoundingClientRect();return[(e.clientX-r.left)*W/r.width,(e.clientY-r.top)*H/r.height]}
  const hit=(x,y)=>{const ctx=cv.current.getContext('2d');return[...st.layers].reverse().find(l=>{
    let w=l.w,h=l.h;if(l.t==='text'){ctx.font=`${l.size}px ${l.font}`;w=ctx.measureText(l.text).width;h=l.size}
    return Math.abs(x-l.x)<w/2&&Math.abs(y-l.y)<h/2})}
  const down=e=>{const[x,y]=pos(e),l=hit(x,y);if(!l)return;setSel(l.id);setPast(p=>[...p,st]);setFuture([]);drag.current={id:l.id,dx:x-l.x,dy:y-l.y};e.currentTarget.setPointerCapture(e.pointerId)}
  const move=e=>{const d=drag.current;if(!d)return;const[x,y]=pos(e);setSt(s=>({...s,layers:s.layers.map(l=>l.id===d.id?{...l,x:x-d.dx,y:y-d.dy}:l)}))}

  const addText=()=>{const id=Date.now();commit({...st,layers:[...st.layers,{id,t:'text',x:W/2,y:H/3,text:'New text',size:Math.round(W/16),color:'#38bdf8',font:'Sora'}]});setSel(id)}
  const addImg=(src,back)=>{const i=new Image();i.onload=()=>{const s=back?Math.max(W/i.width,H/i.height):Math.min(W/i.width,H/i.height)*.6,id=Date.now(),L={id,t:'img',src,x:W/2,y:H/2,w:i.width*s,h:i.height*s}
    setSt(c=>({...c,layers:back?[L,...c.layers]:[...c.layers,L]}));setSel(id)};i.onerror=()=>setMsg('That image could not be loaded.');i.src=src}
  const upload=e=>{const f=e.target.files[0];e.target.value='';if(!f)return
    if(!f.type.startsWith('image/'))return setMsg('Choose an image file (PNG, JPG or WebP).')
    if(f.size>10e6)return setMsg('Image is over 10 MB. Choose a smaller file.')
    const r=new FileReader();r.onload=()=>addImg(r.result);r.readAsDataURL(f)}
  const del=()=>{commit({...st,layers:st.layers.filter(l=>l.id!==sel)});setSel(null)}
  const up=id=>{const a=[...st.layers],i=a.findIndex(l=>l.id===id);if(i<a.length-1){[a[i],a[i+1]]=[a[i+1],a[i]];commit({...st,layers:a})}}

  const generate=async()=>{
    if(!AI)return setMsg('No AI backend is connected yet. Set VITE_AI_ENDPOINT to your own serverless function (see README).')
    if(prompt.trim().length<3)return setMsg('Describe your image in at least 3 characters.')
    setBusy(true);setMsg('')
    try{const r=await fetch(AI,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt,preset,width:W,height:H})})
      if(!r.ok)throw new Error((await r.text())||r.status);const{image}=await r.json();addImg(image,true)}
    catch(e){setMsg('Generation failed: '+e.message)}finally{setBusy(false)}}
  const save=()=>saveProject({name:`${preset} ${new Date().toLocaleDateString()}`,preset,data:st},user).then(()=>setMsg('Saved. Find it in your dashboard.')).catch(e=>setMsg(e.message))
  const download=()=>cv.current.toBlob(b=>{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=`pixel-${preset}.png`;a.click();URL.revokeObjectURL(a.href);logDownload(preset)},'image/png')

  return<div className="grid lg:grid-cols-[1fr_320px] gap-5 pb-10">
    <div>
      <div className="flex flex-wrap gap-2 mb-3">
        <button className="btn" onClick={undo} disabled={!past.length}>Undo</button>
        <button className="btn" onClick={redo} disabled={!future.length}>Redo</button>
        <button className="btn" onClick={addText}>Add text</button>
        <label className="btn cursor-pointer">Upload image<input type="file" accept="image/*" hidden onChange={upload}/></label>
        <button className="btn" onClick={save}>Save</button>
        <button className="btn-primary" onClick={download}>Download PNG</button>
      </div>
      <div className="glass p-3"><canvas ref={cv} width={W} height={H} onPointerDown={down} onPointerMove={move} onPointerUp={()=>drag.current=null} className="mx-auto max-w-full max-h-[70vh] touch-none rounded-lg" aria-label="Design canvas. Drag layers to move them."/></div>
      {msg&&<p role="alert" className="mt-3 text-sm text-amber-300">{msg}</p>}
    </div>
    <aside className="space-y-4">
      <section className="glass p-4"><h2 className="font-display font-bold mb-2">AI background</h2>
        <input className="input" value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Neon city at night, cinematic"/>
        <button className="btn-primary w-full mt-2 flex justify-center gap-2" onClick={generate} disabled={busy}>{busy&&<span className="h-4 w-4 rounded-full border-2 border-white/30 border-t-white animate-spin"/>}{busy?'Generating':'Generate'}</button>
        <p className="text-xs text-white/50 mt-2">{AI?'Credits are set by your backend.':'AI credits: 0. No backend connected, so generation is off.'}</p></section>
      <section className="glass p-4"><h2 className="font-display font-bold mb-2">Style</h2>
        <div className="flex gap-2 mb-3">{BGS.map(b=><button key={b} aria-label={'Background '+b} onClick={()=>commit({...st,bg:b})} className="h-8 w-8 rounded-full border border-white/30" style={{background:`linear-gradient(135deg,${b.split(',')[0]},${b.split(',')[1]})`}}/>)}</div>
        <select className="input" value={st.filter} onChange={e=>commit({...st,filter:e.target.value})} aria-label="Photo filter">{Object.keys(FILTERS).map(f=><option key={f}>{f}</option>)}</select></section>
      {cur?.t==='text'&&<section className="glass p-4 space-y-2"><h2 className="font-display font-bold">Text</h2>
        <input className="input" value={cur.text} onChange={e=>upd({text:e.target.value})} aria-label="Text"/>
        <select className="input" value={cur.font} onChange={e=>upd({font:e.target.value})} aria-label="Font">{FONTS.map(f=><option key={f}>{f}</option>)}</select>
        <div className="flex gap-3 items-center"><input type="color" value={cur.color} onChange={e=>upd({color:e.target.value})} aria-label="Text color" className="h-9 w-12 bg-transparent"/><input type="range" min="20" max={W/3} value={cur.size} onChange={e=>upd({size:+e.target.value})} className="flex-1" aria-label="Size"/></div></section>}
      <section className="glass p-4"><h2 className="font-display font-bold mb-2">Layers</h2>
        <ul className="space-y-1">{[...st.layers].reverse().map(l=><li key={l.id} className={`flex items-center gap-2 rounded-lg px-2 py-1 text-sm ${l.id===sel?'bg-white/15':''}`}>
          <button className="flex-1 text-left truncate" onClick={()=>setSel(l.id)}>{l.t==='img'?'Image':l.text}</button>
          <button className="btn !px-2 !py-1" onClick={()=>up(l.id)} aria-label="Move layer up">Up</button></li>)}</ul>
        <button className="btn w-full mt-2" onClick={del} disabled={!cur}>Delete selected</button></section>
    </aside></div>}
