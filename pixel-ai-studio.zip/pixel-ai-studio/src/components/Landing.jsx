import {useState} from 'react'
import {TOOLS,TEMPLATES,PLANS,FAQ,REVIEWS} from '../lib/data'
import {SIZES} from './Editor'
const openTpl=t=>{const[W,H]=SIZES[t.preset];sessionStorage.setItem('pas_open',JSON.stringify({bg:t.bg,filter:'None',layers:[{id:1,t:'text',x:W/2,y:H/2,text:t.text,size:Math.round(W/9),color:'#ffffff',font:'Impact'}]}));location.hash='#/editor/'+t.preset}
const Sec=({id,title,children})=><section id={id} className="max-w-6xl mx-auto px-4 py-14 scroll-mt-20"><h2 className="font-display text-2xl sm:text-3xl font-extrabold mb-6">{title}</h2>{children}</section>

function BeforeAfter(){const[v,setV]=useState(50);return<div className="relative h-64 sm:h-80 rounded-2xl overflow-hidden select-none glass">
  <div className="absolute inset-0 grayscale brightness-75 bg-gradient-to-br from-slate-500 to-slate-800 grid place-items-center text-2xl font-bold">Before</div>
  <div className="absolute inset-0 bg-gradient-to-br from-violet-600 via-fuchsia-500 to-sky-400 grid place-items-center text-2xl font-bold" style={{clipPath:`inset(0 0 0 ${v}%)`}}>After</div>
  <input type="range" min="0" max="100" value={v} onChange={e=>setV(+e.target.value)} aria-label="Compare before and after" className="absolute bottom-3 left-4 right-4"/>
  <span className="absolute top-3 right-3 text-xs bg-black/50 rounded px-2 py-1">Illustrative demo</span></div>}

export default function Landing(){
  const[note,setNote]=useState('')
  return<main>
    <section className="max-w-6xl mx-auto px-4 pt-32 pb-12 grid md:grid-cols-2 gap-10 items-center">
      <div><h1 className="font-display text-4xl sm:text-6xl font-extrabold leading-[1.05]">Your Imagination. <span className="bg-gradient-to-r from-violet-400 to-sky-400 bg-clip-text text-transparent">Powered by AI.</span></h1>
        <p className="mt-5 text-lg text-white/70 max-w-md">Create stunning thumbnails, posters, images and videos in seconds.</p>
        <div className="mt-7 flex flex-wrap gap-3"><a href="#/auth" className="btn-primary !px-6 !py-3">Get Started Free</a><a href="#/tools" className="btn !px-6 !py-3">Explore AI Tools</a></div></div>
      <div className="glass p-4 float"><div className="aspect-video rounded-xl bg-gradient-to-br from-violet-700 via-indigo-600 to-sky-400 grid place-items-center font-display text-3xl sm:text-4xl font-extrabold [text-shadow:0_3px_0_#000]">EPIC WIN</div>
        <p className="mt-3 text-xs text-white/50">Demo preview. Open the editor to make your own.</p></div></section>
    <Sec id="tools" title="AI tools"><div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">{TOOLS.map(t=><a key={t.id} href={t.live?'#/editor/'+t.id:'#/tool/'+t.id} className="glass p-5 hover:bg-white/10 transition block">
      <h3 className="font-display font-bold">{t.name}</h3><p className="text-sm text-white/60 mt-2">{t.d}</p><span className={`inline-block mt-3 text-xs rounded-full px-2 py-0.5 ${t.live?'bg-emerald-500/20 text-emerald-300':'bg-amber-500/20 text-amber-300'}`}>{t.live?'Editor ready':'Needs integration'}</span></a>)}</div></Sec>
    <Sec id="templates" title="Popular templates"><div className="grid grid-cols-2 md:grid-cols-3 gap-4">{TEMPLATES.map(t=><button key={t.name} onClick={()=>openTpl(t)} className="glass p-3 text-left hover:bg-white/10 transition">
      <div className="h-28 rounded-lg grid place-items-center font-display font-extrabold text-xl" style={{background:`linear-gradient(135deg,${t.bg.split(',')[0]},${t.bg.split(',')[1]})`}}>{t.text}</div><p className="mt-2 text-sm font-medium">{t.name}</p></button>)}</div></Sec>
    <Sec id="showcase" title="Before and after"><BeforeAfter/></Sec>
    <Sec id="reviews" title="What creators say"><div className="grid md:grid-cols-3 gap-4">{REVIEWS.map(([n,r,q])=><figure key={n} className="glass p-5"><blockquote className="text-white/80">{q}</blockquote><figcaption className="mt-3 text-sm text-white/50">{n}, {r}</figcaption></figure>)}</div><p className="text-xs text-white/40 mt-3">Sample testimonials. Replace with real ones before launch.</p></Sec>
    <Sec id="pricing" title="Pricing"><div className="grid md:grid-cols-3 gap-4">{PLANS.map(p=><div key={p.n} className="glass p-6 flex flex-col"><h3 className="font-display font-bold text-xl">{p.n}</h3><p className="text-3xl font-extrabold mt-2">{p.p}<span className="text-sm text-white/50 font-normal"> /month</span></p><p className="text-sky-300 text-sm mt-1">{p.c}</p>
      <ul className="mt-4 space-y-1 text-sm text-white/70 flex-1">{p.f.map(f=><li key={f}>{f}</li>)}</ul>
      {p.n==='Free'?<a href="#/auth" className="btn-primary text-center mt-5">Start free</a>:<button className="btn mt-5" onClick={()=>setNote(`${p.n} is not available yet. Payments are not configured and nothing was charged.`)}>Choose {p.n}</button>}</div>)}</div>
      {note&&<p role="status" className="mt-4 text-amber-300 text-sm">{note}</p>}<p className="text-xs text-white/40 mt-3">Example prices and credit limits. Edit them in src/lib/data.js.</p></Sec>
    <Sec id="faq" title="FAQ"><div className="space-y-3 max-w-3xl">{FAQ.map(([q,a])=><details key={q} className="glass p-4"><summary className="cursor-pointer font-medium">{q}</summary><p className="mt-2 text-white/70 text-sm">{a}</p></details>)}</div></Sec>
  </main>}
