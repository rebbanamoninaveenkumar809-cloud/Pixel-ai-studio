import {useEffect,useState} from 'react'
import {sb} from '../lib/supabase'
import {listProjects,listDownloads} from '../lib/store'
import {TOOLS} from '../lib/data'

export function Auth(){
  const[mode,setMode]=useState('signup'),[f,setF]=useState({email:'',pw:''}),[err,setErr]=useState(''),[busy,setBusy]=useState(false)
  const submit=async e=>{e.preventDefault()
    if(!/^\S+@\S+\.\S+$/.test(f.email))return setErr('Enter a valid email address.')
    if(f.pw.length<8)return setErr('Password must be at least 8 characters.')
    if(!sb)return setErr('Accounts are off because Supabase is not configured. Continue as guest below.')
    setBusy(true);setErr('')
    const{error}=mode==='signup'?await sb.auth.signUp({email:f.email,password:f.pw}):await sb.auth.signInWithPassword({email:f.email,password:f.pw})
    setBusy(false);error?setErr(error.message):(location.hash='#/dashboard')}
  const google=()=>sb?sb.auth.signInWithOAuth({provider:'google',options:{redirectTo:location.origin}}):setErr('Google login needs Supabase with the Google provider enabled.')
  return<main className="pt-28 px-4 max-w-md mx-auto"><form onSubmit={submit} noValidate className="glass p-6 space-y-3">
    <h1 className="font-display text-2xl font-bold">{mode==='signup'?'Create your account':'Welcome back'}</h1>
    <input className="input" type="email" placeholder="Email" autoComplete="email" value={f.email} onChange={e=>setF({...f,email:e.target.value})} aria-label="Email"/>
    <input className="input" type="password" placeholder="Password (8+ characters)" autoComplete={mode==='signup'?'new-password':'current-password'} value={f.pw} onChange={e=>setF({...f,pw:e.target.value})} aria-label="Password"/>
    {err&&<p role="alert" className="text-sm text-amber-300">{err}</p>}
    <button className="btn-primary w-full" disabled={busy}>{busy?'Please wait':mode==='signup'?'Sign up':'Log in'}</button>
    <button type="button" className="btn w-full" onClick={google}>Continue with Google</button>
    <button type="button" className="text-sm text-sky-300" onClick={()=>setMode(mode==='signup'?'login':'signup')}>{mode==='signup'?'Have an account? Log in':'New here? Sign up'}</button>
    <a href="#/editor/thumbnail" className="block text-sm text-white/60">Continue as guest</a></form></main>}

export function Dashboard({user}){
  const[ps,setPs]=useState(null),[err,setErr]=useState(''),[name,setName]=useState(user?.user_metadata?.name||localStorage.getItem('pas_name')||''),[ok,setOk]=useState('')
  useEffect(()=>{listProjects(user).then(setPs).catch(e=>{setErr(e.message);setPs([])})},[user])
  const open=p=>{sessionStorage.setItem('pas_open',JSON.stringify(p.data));location.hash='#/editor/'+p.preset}
  const saveName=async()=>{localStorage.setItem('pas_name',name);if(sb&&user)await sb.auth.updateUser({data:{name}});setOk('Profile saved.')}
  const dl=listDownloads()
  return<main className="pt-28 px-4 max-w-5xl mx-auto pb-12 space-y-6">
    <h1 className="font-display text-3xl font-bold">{name?`Hi, ${name}`:'Your dashboard'}</h1>
    <section className="glass p-5"><h2 className="font-display font-bold mb-3">Saved projects</h2>
      {err&&<p role="alert" className="text-amber-300 text-sm">{err}</p>}
      {!ps?<div className="h-5 w-5 rounded-full border-2 border-white/30 border-t-white animate-spin"/>:ps.length?<ul className="grid sm:grid-cols-2 gap-2">{ps.map(p=><li key={p.id} className="flex justify-between items-center bg-white/5 rounded-lg p-3 text-sm"><span>{p.name}</span><button className="btn" onClick={()=>open(p)}>Open</button></li>)}</ul>:<p className="text-white/60 text-sm">Nothing saved yet. <a className="text-sky-300" href="#/editor/thumbnail">Make your first design.</a></p>}</section>
    <section className="glass p-5"><h2 className="font-display font-bold mb-3">Download history</h2>{dl.length?<ul className="text-sm text-white/70 space-y-1">{dl.slice(0,8).map((d,i)=><li key={i}>{d.preset}, {new Date(d.at).toLocaleString()}</li>)}</ul>:<p className="text-white/60 text-sm">No downloads yet.</p>}</section>
    <section className="glass p-5 space-y-3 max-w-md"><h2 className="font-display font-bold">Profile</h2>
      <p className="text-sm text-white/60">{user?.email||'Guest mode: data stays in this browser.'}</p>
      <input className="input" value={name} onChange={e=>setName(e.target.value)} placeholder="Display name" aria-label="Display name"/>
      <div className="flex gap-2"><button className="btn-primary" onClick={saveName}>Save profile</button>{user&&<button className="btn" onClick={()=>sb.auth.signOut().then(()=>location.hash='#/')}>Log out</button>}</div>{ok&&<p role="status" className="text-sm text-emerald-300">{ok}</p>}</section></main>}

export function Pending({id}){
  const t=TOOLS.find(x=>x.id===id)||TOOLS[6]
  return<main className="pt-28 px-4 max-w-3xl mx-auto"><div className="glass p-6"><h1 className="font-display text-3xl font-bold">{t.name}</h1><p className="mt-3 text-white/70">{t.d}</p>
    <p className="mt-4 text-amber-300 text-sm">Not connected. This tool is off until you add the integration in the README.</p>
    <div className="mt-5 rounded-xl bg-black/40 p-4 text-sm text-white/60"><b className="text-white/80">Demo preview, not real output</b>
      {t.id==='text'?<ul className="mt-2 space-y-1"><li>I tried the new AI editor for a week</li><li>#creator #youtube #design</li></ul>:<div className="mt-3 h-10 rounded bg-gradient-to-r from-violet-600 to-sky-500 w-2/3"/>}</div>
    <a href="#/tools" className="btn inline-block mt-5">Back to tools</a></div></main>}
