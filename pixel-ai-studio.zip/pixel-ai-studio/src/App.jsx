import {useEffect,useState} from 'react'
import {sb} from './lib/supabase'
import Landing from './components/Landing'
import Editor from './components/Editor'
import {Auth,Dashboard,Pending} from './components/Pages'
const LINKS=[['Tools','tools'],['Templates','templates'],['Showcase','showcase'],['Pricing','pricing'],['FAQ','faq']]
const SOCIAL=[['YouTube','https://youtube.com'],['Instagram','https://instagram.com'],['X','https://x.com'],['Facebook','https://facebook.com']]
export default function App(){
  const[h,setH]=useState(location.hash||'#/'),[user,setUser]=useState(null),[open,setOpen]=useState(false)
  useEffect(()=>{const f=()=>{setH(location.hash||'#/');setOpen(false)};addEventListener('hashchange',f);return()=>removeEventListener('hashchange',f)},[])
  useEffect(()=>{if(!sb)return;sb.auth.getSession().then(({data})=>setUser(data.session?.user??null));const{data}=sb.auth.onAuthStateChange((_,s)=>setUser(s?.user??null));return()=>data.subscription.unsubscribe()},[])
  const[,r,a]=h.split('/'),route=r||'home'
  useEffect(()=>{const el=['tools','templates','showcase','pricing','faq'].includes(route)&&document.getElementById(route);el?el.scrollIntoView({behavior:'smooth'}):window.scrollTo(0,0)},[h])
  const page=route==='editor'?<main className="pt-24 px-4 max-w-7xl mx-auto"><Editor key={a} preset={a} user={user}/></main>:route==='auth'?<Auth/>:route==='dashboard'?<Dashboard user={user}/>:route==='tool'?<Pending id={a}/>:<Landing/>
  return<>
    <header className="fixed top-0 inset-x-0 z-50 glass !rounded-none"><nav className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
      <a href="#/" className="font-display font-extrabold tracking-wide bg-gradient-to-r from-violet-400 to-sky-400 bg-clip-text text-transparent">PIXEL AI STUDIO</a>
      <div className={`${open?'flex':'hidden'} md:flex absolute md:static top-14 inset-x-0 flex-col md:flex-row gap-1 md:gap-5 items-start md:items-center bg-[#07040f] md:bg-transparent p-4 md:p-0 text-sm`}>
        {LINKS.map(([l,id])=><a key={id} href={'#/'+id} className="text-white/70 hover:text-white py-1">{l}</a>)}
        <a href="#/dashboard" className="text-white/70 hover:text-white py-1">Dashboard</a>
        {user?<span className="text-white/50 truncate max-w-[10rem]">{user.email}</span>:<a href="#/auth" className="btn-primary">Sign up</a>}</div>
      <button className="md:hidden btn" onClick={()=>setOpen(!open)} aria-expanded={open} aria-label="Menu">{open?'Close':'Menu'}</button></nav></header>
    {page}
    <footer className="border-t border-white/10 mt-10 py-8 px-4 text-sm text-white/50"><div className="max-w-6xl mx-auto flex flex-wrap gap-4 justify-between"><span>© 2026 PIXEL AI STUDIO</span>
      <div className="flex gap-4">{SOCIAL.map(([n,u])=><a key={n} href={u} target="_blank" rel="noopener noreferrer" className="hover:text-white">{n}</a>)}</div></div></footer></>}
